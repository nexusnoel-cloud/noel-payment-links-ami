export default function Home(){
  return <main style={{maxWidth:680,margin:'0 auto',padding:'72px 20px'}}>
    <div style={{background:'#fff',borderRadius:24,padding:36,boxShadow:'0 10px 40px rgba(0,0,0,.06)'}}>
      <div style={{fontSize:12,letterSpacing:2,color:'#6c766f'}}>NOÉL</div>
      <h1 style={{fontSize:28,margin:'18px 0 10px'}}>PAYMENT</h1>
      <p style={{lineHeight:1.8,color:'#5b635e'}}>お送りした専用のお支払いリンクからお進みください。</p>
    </div>
  </main>;
}
